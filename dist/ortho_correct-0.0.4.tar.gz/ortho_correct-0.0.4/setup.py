from setuptools import setup, find_packages

setup(name='ortho_correct',
      version='0.0.4',
      description='a spell checker',
      author='Xin',
      author_email='chenxin9812@gmail.com',
      url='https://github.com/pypa/sampleproject',
      packages=find_packages(),
      install_requires=[
            'Spacy',
            'requests'
      ]
     )
