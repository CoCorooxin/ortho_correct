#### Spell Checker

A spell checker for French language based on levenshstein distance and Peter Norvig generative algorithm. 

The user can download the package through the command line



